const https = require('https')
// const http = require('http')
const querystring = require('querystring')
const md5 = require('./md5')
const api_key = 'a04faf5d-4eb8-4b25-8736-8440af7e5d3b'
const sec_key = '70CC772D5D63A35E2FED8CF1BA00907A'
const express = require('express')
const app = express()


var infoContainer =
  {
    userInfo:
      {
        totalEOS: '',
        profitLoss: '',
        open: '',
        openProfit: ''
      },
    positionInfo:
    {
      shortInfo:
        {
          openPrice: '',
          profitLossRatio: '',
          profitLoss: '',
          holding: '',
          available: '',
          margin: '',
          deadPrice: ''
        },
      longInfo:
        {
          openPrice: '',
          profitLossRatio: '',
          profitLoss: '',
          holding: '',
          available: '',
          margin: '',
          deadPrice: ''
        }
    }
  }


var engine = setInterval(() => {
  var infoSign = md5('api_key=' + api_key + '&secret_key=' + sec_key).toUpperCase()
  var userInfoData = querystring.stringify({
    api_key: 'a04faf5d-4eb8-4b25-8736-8440af7e5d3b',
    sign: infoSign
  })
  const userInfoOpt = {
    host: 'www.okex.com',
    path: '/api/v1/future_userinfo_4fix.do',
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    }
  }
  
  
  var positionSign = md5('api_key=' + api_key + '&contract_type=quarter&symbol=eos_usd&type=1' + '&secret_key=' + sec_key).toUpperCase()
  var positionInfoData = querystring.stringify({
    symbol: 'eos_usd',
    contract_type: 'quarter',
    api_key: 'a04faf5d-4eb8-4b25-8736-8440af7e5d3b',
    sign: positionSign,
    type: '1'
  })
  const positionInfoOpt = {
    host: 'www.okex.com',
    path: '/api/v1/future_position_4fix.do',
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded'
    }
  }
  
  
  const userInfoGrabber = https.request(userInfoOpt, (res) => {
    var dataArr = []
    var dataArrLen = 0
    res.on('data', (d) => {
      dataArr.push(d)
      dataArrLen += d.length
    })
    res.on('end', () => {
      var userInfo = JSON.parse(Buffer.concat(dataArr, dataArrLen).toString()).info
      infoContainer.userInfo.totalEOS = userInfo.eos.rights
      infoContainer.userInfo.profitLoss = userInfo.eos.contracts[0].profit
      infoContainer.userInfo.openProfit = userInfo.eos.contracts[0].unprofit
      infoContainer.userInfo.open = userInfo.eos.contracts[0].bond
      // console.log(infoContainer)
    })
  })
  userInfoGrabber.on('error', (e) => {
    console.error(e);
  });
  userInfoGrabber.write(userInfoData);
  userInfoGrabber.end();
  
  
  const positionInfoGrabber = https.request(positionInfoOpt, (res) => {
    var dataArr = []
    var dataArrLen = 0
    res.on('data', (d) => {
      dataArr.push(d)
      dataArrLen += d.length
    })
    res.on('end', () => {
      var positionInfo = JSON.parse(Buffer.concat(dataArr, dataArrLen).toString()).holding[0]
      infoContainer.positionInfo.shortInfo.openPrice = positionInfo.sell_price_avg
      infoContainer.positionInfo.shortInfo.profitLossRatio = positionInfo.sell_profit_lossratio
      infoContainer.positionInfo.shortInfo.profitLoss = (positionInfo.sell_bond * positionInfo.sell_profit_lossratio / 100)
      infoContainer.positionInfo.shortInfo.holding = positionInfo.sell_amount
      infoContainer.positionInfo.shortInfo.available = positionInfo.sell_available
      infoContainer.positionInfo.shortInfo.margin = positionInfo.sell_bond
      infoContainer.positionInfo.shortInfo.deadPrice = positionInfo.sell_flatprice
      
      infoContainer.positionInfo.longInfo.openPrice = positionInfo.buy_price_avg
      infoContainer.positionInfo.longInfo.profitLossRatio = positionInfo.buy_profit_lossratio
      infoContainer.positionInfo.longInfo.profitLoss = (positionInfo.buy_bond * positionInfo.buy_profit_lossratio / 100)
      infoContainer.positionInfo.longInfo.holding = positionInfo.buy_amount
      infoContainer.positionInfo.longInfo.available = positionInfo.buy_available
      infoContainer.positionInfo.longInfo.margin = positionInfo.buy_bond
      infoContainer.positionInfo.longInfo.deadPrice = positionInfo.buy_flatprice
    })
  })
  positionInfoGrabber.on('error', (e) => {
    console.error(e);
  });
  positionInfoGrabber.write(positionInfoData)
  positionInfoGrabber.end()
}, 10000)

var seeThruEngine = setInterval(() => {
  console.log(infoContainer)
}, 10000)

// var autoDrive = setInterval(() => {
//   var options = {
//     host: 'm1e7pv64.qcloud.la',
//     path: '/weapp/webhook',
//     port: 5757,
//     method: 'POST',
//     headers: {
//       'Content-Type': 'application/json'
//     }
//   }
//   var body = JSON.stringify(infoContainer)
//   var req = https.request(options, (res) => {
//     res.on('data', (d) => {
//       console.log(d.toString())
//     })
//   })
//   req.on('error', (e) => {
//     console.error(e);
//   });
//   req.write(body)
//   console.log(infoContainer)
//   req.end()
// }, 5000)

app.get('/info', (req, res) => res.send(JSON.stringify(infoContainer)))

app.listen(8888, () => console.log('hzkd_app is running at port 8888.'))